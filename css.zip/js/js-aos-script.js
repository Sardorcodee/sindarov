// Aos Js starting
AOS.init({
    mirror: true,
    easing: 'ease',
    duration:1000
});